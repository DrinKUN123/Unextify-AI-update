<?php 
session_start();

if(!isset($_SESSION['examineeSession']['examineenakalogin']) == true) header("location:index.php");


 ?>
<?php include("conn.php"); ?>

<?php include("includes/header.php"); ?>      

<?php include("includes/ui-theme.php"); ?>

<div class="app-main">

<?php include("includes/sidebar.php"); ?>


<?php 
   @$page = $_GET['page'];


   if($page != '')
   {
     if($page == "exam")
     {
       include("pages/exam.php");
     }
     else if($page == "result")
     {
       include("pages/result.php");
     }
     else if($page == "myscores")
     {
       include("pages/myscores.php");
     }
     
   }
   else
   {
     include("pages/home.php"); 
   }


 ?> 

<?php include("includes/footer.php"); ?>

<?php include("includes/modals.php"); ?>



<!-- Chatbot UI -->


<!-- Chatbot UI -->
<style>
  #chatbot-container {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 300px;
    background: white;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0px 0px 10px #aaa;
    z-index: 9999;
    font-family: Arial;
  }
  #chatbot-header {
    background: #3b5998;
    color: white;
    padding: 10px;
    font-weight: bold;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
  #chatbot-messages {
    height: 200px;
    overflow-y: auto;
    padding: 10px;
    font-size: 14px;
  }
  #chatbot-input {
    display: flex;
    border-top: 1px solid #ccc;
  }
  #chatbot-input input {
    flex: 1;
    padding: 10px;
    border: none;
    outline: none;
  }
  #chatbot-input button {
    background: #3b5998;
    color: white;
    border: none;
    padding: 0 15px;
    cursor: pointer;
  }
</style>

<div id="chatbot-container">
  <div id="chatbot-header">AI Assistant</div>
  <div id="chatbot-messages"></div>
  <div id="chatbot-input">
    <input type="text" id="chat-input" placeholder="Ask me about the system...">
    <button onclick="sendMessage()">Send</button>
  </div>
</div>

<script>
  function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    if (!message) return;

    const messagesDiv = document.getElementById('chatbot-messages');
    messagesDiv.innerHTML += `<div><b>You:</b> ${message}</div>`;
    input.value = '';

    fetch('chatbot.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: `message=${encodeURIComponent(message)}`
    })
    .then(res => res.text())
    .then(response => {
      messagesDiv.innerHTML += `<div><b>Bot:</b> ${response}</div>`;
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    })
    .catch(err => {
      messagesDiv.innerHTML += `<div><b>Bot:</b> Error contacting chatbot.</div>`;
    });
  }
</script>
