<?php 
session_start();
include("../conn.php");

extract($_POST);

// Prepare and execute a safe query to get the examinee by email
$selAcc = $conn->prepare("SELECT * FROM examinee_tbl WHERE exmne_email = ?");
$selAcc->execute([$username]);
$selAccRow = $selAcc->fetch(PDO::FETCH_ASSOC);

if ($selAccRow && password_verify($pass, $selAccRow['exmne_password'])) {
    // Password is correct, create session
    $_SESSION['examineeSession'] = array(
        'exmne_id' => $selAccRow['exmne_id'],
        'examineenakalogin' => true
    );
    $res = array("res" => "success");
} else {
    // Invalid login
    $res = array("res" => "invalid");
}

echo json_encode($res);
?>
