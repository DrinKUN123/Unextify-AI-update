<?php
include("../../../conn.php");
extract($_POST);

/* ——— NEW FUNCTION: check password strength ——— */
function isStrongPassword(string $pwd): bool
{
    return  strlen($pwd) >= 8 &&                 // min length
            preg_match('/[A-Z]/', $pwd) &&       // ≥1 upper-case
            preg_match('/[a-z]/', $pwd) &&       // ≥1 lower-case
            preg_match('/[0-9]/', $pwd) &&       // ≥1 digit
            preg_match('/[\W_]/', $pwd);         // ≥1 special char
}

/* capture the raw password before we tamper with it */
$passwordPlain = $password;

/*   —— validation block ——   */
if (!isStrongPassword($passwordPlain)) {
    echo json_encode(["res" => "weakPassword"]);
    exit;                        // stop further processing
}

$selExamineeFullname = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_fullname='$fullname' ");
$selExamineeEmail    = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_email='$email' ");

if ($gender == "0")          { $res = ["res" => "noGender"];         }
elseif ($course == "0")      { $res = ["res" => "noCourse"];         }
elseif ($year_level == "0")  { $res = ["res" => "noLevel"];          }
elseif ($selExamineeFullname->rowCount() > 0)
                            { $res = ["res" => "fullnameExist","msg"=>$fullname]; }
elseif ($selExamineeEmail->rowCount() > 0)
                            { $res = ["res" => "emailExist","msg"=>$email]; }
else {
    /*— HASH WITH ARGON2id (falls back to bcrypt if not available) —*/
    $passwordHash = password_hash($passwordPlain,
                     defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT);

    $insData = $conn->query("INSERT INTO examinee_tbl
        (exmne_fullname,exmne_course,exmne_gender,exmne_birthdate,exmne_year_level,exmne_email,exmne_password)
        VALUES('$fullname','$course','$gender','$bdate','$year_level','$email','$passwordHash')");

    $res = $insData ? ["res"=>"success","msg"=>$email] : ["res"=>"failed"];
}

echo json_encode($res);
?>
