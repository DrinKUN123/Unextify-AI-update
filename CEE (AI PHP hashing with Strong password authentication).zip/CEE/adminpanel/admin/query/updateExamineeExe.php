<?php
include("../../../conn.php");
extract($_POST);

function isStrongPassword(string $pwd): bool
{
    return  strlen($pwd) >= 8 &&
            preg_match('/[A-Z]/',$pwd) &&
            preg_match('/[a-z]/',$pwd) &&
            preg_match('/[0-9]/',$pwd) &&
            preg_match('/[\W_]/',$pwd);
}

/* use the submitted value if one was given; otherwise keep the old hash */
if (!empty($exPass)) {
    if (!isStrongPassword($exPass)) {
        echo json_encode(["res"=>"weakPassword"]);
        exit;
    }
    $passwordClause = "exmne_password = " .
        $conn->quote(
            password_hash($exPass,
                defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT)
        ) . ",";
} else {
    $passwordClause = "";  // no password change
}

$upd = $conn->query("UPDATE examinee_tbl SET
        exmne_fullname = '$exFullname',
        exmne_course   = '$exCourse',
        exmne_gender   = '$exGender',
        exmne_birthdate= '$exBdate',
        exmne_year_level = '$exYrlvl',
        exmne_email    = '$exEmail',
        $passwordClause
        exmne_id       = exmne_id   /* no change, just to keep syntax tidy */
        WHERE exmne_id = '$exmne_id'");

echo json_encode($upd ? ["res"=>"success","exFullname"=>$exFullname]
                      : ["res"=>"failed"]);
?>
