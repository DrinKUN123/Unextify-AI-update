<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userMessage = $_POST["message"];

    // Block exam answer requests
    if (preg_match('/\b(answer|correct|solution)\b/i', $userMessage)) {
        echo "❌ Sorry, I can't provide answers to exam questions.";
        exit;
    }

    $apiKey = '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';

    $client = new Client([
        'base_uri' => 'https://openrouter.ai/api/v1/',
        'headers' => [
            'Authorization' => 'Bearer ' . $apiKey,
            'HTTP-Referer' => 'http://localhost/cee', // required by OpenRouter
            'Content-Type'  => 'application/json',
        ],
        'timeout' => 20.0,
    ]);

    $payload = [
        'model' => 'deepseek/deepseek-r1-distill-llama-70b:free',
        'messages' => [
            [
                'role' => 'system',
                'content' => <<<EOT
You are a helpful assistant for an exam system. You explain how the system works, including navigation, available exams, results, feedback, scores, and retakes — but you NEVER provide answers to exam questions.

System layout and navigation:
- When users log in, they land on the Dashboard.
- On the **left side of the screen**, there is a menu titled **AVAILABLE EXAM'S**.
- Under that, there is a section called **All Exam's**, where the user can view and start exams.
- Exam results can be viewed by clicking the **Results** tab on the same menu.
- Users can submit feedback through the **Feedback** section at the bottom of the left menu.
- Retakes are allowed based on exam policy, and retake options appear in the **Results** tab if available.

Always provide clear, friendly explanations, and guide users to the correct section of the system based on their question.
EOT
            ],
            ['role' => 'user', 'content' => $userMessage]
        ],
    ];

    try {
        $response = $client->post('chat/completions', ['json' => $payload]);
        $data = json_decode($response->getBody(), true);
        echo $data['choices'][0]['message']['content'];
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage();
    }
}
?>
